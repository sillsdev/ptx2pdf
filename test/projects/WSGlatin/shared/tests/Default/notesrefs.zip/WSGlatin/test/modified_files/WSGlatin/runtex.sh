#!/bin/sh
cd local/ptxprint/Default
hyph_size=32749 stack_size=32768 FONTCONFIG_FILE=`pwd`/../../../fonts.conf TEXINPUTS=../../../src//:. MISCFONTS=../../../shared/fonts:../../../src: xetex WSGlatin_Default_RUT_ptxp.tex