#!/bin/sh
cd local/ptxprint/PicsJON
hyph_size=32749 stack_size=32768 FONTCONFIG_FILE=`pwd`/../../../fonts.conf TEXINPUTS=../../../src//:. MISCFONTS=../../../shared/fonts:../../../src: xetex WSGlatin_PicsJON_JON_ptxp.tex