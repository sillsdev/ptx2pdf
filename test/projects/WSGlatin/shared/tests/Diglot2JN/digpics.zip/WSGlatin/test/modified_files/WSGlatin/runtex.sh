#!/bin/sh
cd local/ptxprint/Mono2JN